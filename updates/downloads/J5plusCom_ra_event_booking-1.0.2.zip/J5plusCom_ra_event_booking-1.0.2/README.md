Bookings component that works with Ramblers Library
