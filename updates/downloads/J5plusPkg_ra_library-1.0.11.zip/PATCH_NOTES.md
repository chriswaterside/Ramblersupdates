# com_ra_library patch notes (cumulative; plg_system_rastyling is untouched)

Bulk photo upload ("Add several photos at once", Photos tab of Past Walk / Route)
- 1.0.13.sql (+ install.mysql.utf8.sql): file_hash column on #__ra_library_images
- ImageGalleryHelper: stores SHA-1 of each original upload; addBulkUploads(), enqueueBulkSummary(), getBulkUploadLimits()
- PastwalkModel / RouteModel::save(): call addBulkUploads() after saveImages()
- media/js/fields/bulkimages.js: checks count / size against PHP limits before submit

Custom fields (Joomla com_fields), contexts com_ra_library.pastwalk and com_ra_library.route
- Ra_libraryComponent implements FieldsServiceInterface; edit templates show one tab per field group
- {field:name}, {if:field:name}, {if_not:field:name}, {text ?field:name} in SimpleTemplate.php and media/js/ra.js
- ItemRenderer::buildCustomFieldValues(): {custom_fields} and {field:name}

Admin menu
- ra_library.xml: flat submenu in logical order
- script.php postflight()/groupAdminMenu(): adds "Past Walks" and "Routes" group labels (titled separators) and shortens item titles.
  Flat on purpose - a nested heading would be a 4th sidebar level, which Joomla's sidebar does not support (dropdown.js error, no indent).

Photos tab
- ImagepreviewField + imagepreview.js/.css: hover preview and click-to-enlarge viewer
- tmpl/*/edit.php + photogrid.js/.css: "Photo details" / "Reorder photos" sub-tabs

## v5 - category-specific custom fields refresh live
- New `media/js/fields/categoryreload.js`, loaded by the Past Walk and Route edit forms.
- Changing the Category reloads the form (task `pastwalk.reload` / `route.reload`, built into Joomla's FormController): nothing is saved; typed values are kept in the session, and the custom fields for the new category appear.
- If photos/files have been chosen but not saved, a confirmation is shown first (they cannot survive a reload).
- Category field type unchanged (still `category`), so category permission behaviour is unchanged.

## v6 - fields can be assigned to categories
- Added `site/src/Service/PastwalkCategory.php` and `RouteCategory.php`. Joomla needs these to offer the "Category" selector on a custom field (Past Walk Fields / Route Fields > edit field). Without them the selector was hidden, so a field could not be limited to certain categories. Field *groups* are only tab groupings; category assignment is on the field itself.

## v7 - photo limits shown on the forms
- Past Walk and Route edit forms (Photos tab) have a collapsible "Photo limits (n of 50 used)" note listing: total per record and room left, per-batch cap, per-file and per-save size limits from the server's PHP settings, allowed file types, stored sizes.
- The bulk picker now also stops you choosing more photos than there is room for.

## v8 - limit messages name the PHP setting
- Photo limits note and bulk-picker warnings now name the PHP setting that controls each limit (upload_max_filesize, post_max_size, max_file_uploads).

## v9 - fix edit-form error introduced in v8
- "10% for" in the post_max_size limit text was read by sprintf as a format code ("3 arguments are required, 2 given"). Now written as "10%%".

## v10 - stable list ordering across pages
- Display Options, Past Walks and Routes admin lists now add the record id as a final sort tie-breaker, so rows with the same sort value keep one fixed order from page to page (previously MySQL could order tied rows differently on each page).

## v11 - sort kept when paging
- The filter forms' hidden "Sort by" dropdown had no entry for some sortable column headings (Display Options: Display Option; Past Walks and Routes: ID). The dropdown is posted back when you change page, so the sort was lost on page 2+. Entries added (filter_librarydisplays.xml, filter_pastwalks.xml, filter_routes.xml + language strings). Every sortable heading in all three lists now has a matching entry.
- v10's id tie-breaker is kept.

## v12 - background (AJAX) photo upload replaces the save-time bulk picker
- Saved Past Walks / Routes: "Add photos" box (choose many or drag in). Photos upload one request each to `<section>.uploadImage` (new `ImageUploadTrait`), are stored immediately and appear in the Photo details list / reorder grid. Only `upload_max_filesize` and the 50-photo cap apply; `post_max_size`, `max_file_uploads` and the batch memory/time risk no longer do.
- New (unsaved) records show "save this record first" in place of the uploader; the one-photo-at-a-time rows still work.
- Uploaded photos are stored as soon as they finish, even if you then Cancel. Captions/order still save on Save; the uploaded rows are added to the form with their ids so Save keeps them.
- Removed: save-time bulk picker (bulkimages.js), `ImageGalleryHelper::addBulkUploads/enqueueBulkSummary/getBulkUploadLimits`, and their language strings. Added `getUploadLimits()`, `addUploadedPhoto()`.
- Limits note updated (no per-save / per-batch lines).

## v13 - live photo count + remove from the reorder tab
- New `photolimits.js`: the "Photo limits (n of 50 used)" note and the "room for n more" line update as photos are uploaded or removed; the uploader uses the live figure.
- Reorder tab: each photo has a red "x" button. It asks for confirmation, then takes the photo out of the Photo details list (same as that row's own Remove button) and shows a note that the photo is deleted for good on Save.

## v14 - photo viewer from the reorder tab
- Clicking a tile's photo in the Reorder tab opens the large viewer (caption, Prev/Next, arrow keys, Esc), stepping through the grid in its current order. Hover preview works there too. Dragging a tile still reorders it; Ctrl/Shift-click opens the file in a new tab.
- imagepreview.js now steps through only the list the click came from (grid or details list), so photos never appear twice.
- The viewer assets and strings are now loaded by the edit forms themselves, so they also work for photos uploaded into a previously empty gallery.

## v15 - Walks Manager import: photos ticked by default, more reliable download
- Import screen: each walk's photos are now ticked by default (the None / All buttons still work).
- Photo download now uses Joomla's HTTP client (User-Agent, redirects, 30s timeout) instead of file_get_contents, retries up to 3 times on temporary failures (not on 404/403), encodes odd characters in the address, and the error message now says the reason (e.g. "HTTP 404", "Connection timed out") and the photo address.

## v16 - self-contained article tags for documents and single GPX routes
- Merged your updated librarydisplay.xml, DisplayoptionLabelHelper.php and preview images (from your zip). Stale files to delete on a test site that is installed over the top: media/com_ra_library/css/adminmenu.css and media/com_ra_library/js/fields/bulkimages.js.
- New tags, typed straight into an article (no Library Display needed; Content - RA Library plugin must be enabled):
    {ra_library:documents folder="images/minutes" types="pdf,docx" sort="asc"}
    {ra_library:gpx file="images/routes/walk.gpx" colour="#782327" download="Public"}
  Paths must be inside the site's images or files folders (no "..", no symlinks out, no URLs); script/server file types are never listed; colour is validated. Tolerates what rich-text editors do to the tag (curly quotes, &quot;, &nbsp;).
- Plugin plg_content_ra_library 5.0.1 (re-installed with the package); logic is in Site/Helper/PluginHelper.php.
- Hints on the Display Option screens for those two types, and the "ways to add a display" help text.

## v17 - captions and smaller preview images
- Captions fixed: Routes blog -> "Typical Routes blog display"; Routes table -> "Typical Routes Table display".
- All display option preview PNGs resized to at most 900 px on the longest side (about 18 MB -> 6 MB); same file names. SQL table still shows the JSON image until you have a real example.

v18 - complete "how to add to an article" help (Library Display edit screen, Display Option tab)
- Lists all ways to show a display (menu item, module, {ra_library:display:ID} with the real ID filled in once saved, RA Next Walks)
- Collapsible full references for {ra_library:documents ...} (folder, types, sort) and {ra_library:gpx ...} (file, colour, download): defaults, examples, notes/limits/troubleshooting
- The reference for the selected display option opens automatically; short per-tab hints removed

v19 - more self-contained article tags (site/src/Helper/PluginHelper.php; help in the Display Option tab)
- {ra_library:walks groups=".."}  tabbed future walks
- {ra_library:calendar groups=".." size=".."}  future walks calendar
- {ra_library:pastwalks|routes category=".." type="list|blog|table|map|tree"}
- {ra_library:gpxfolder folder=".." colour=".." download=".."}
- {ra_library:plot latitude longitude zoom key}
- {ra_library:csv file=".."}
- Each runs the normal Library Display option with fixed defaults; paths restricted to images/files; warnings for bad values

v20 - PluginHelper loads the component site language file so tags/displays in articles show real text instead of COM_RA_LIBRARY_* keys

v21 - {ra_library:addtocalendar groups=".."} button tag; calendarlink="yes|no" option on walks and calendar tags

v22 - removed the calendarlink option again; only {ra_library:addtocalendar} remains

v23 - help sections reordered on the Display Option tab

v24 - ramblers.css moved from media/com_ra_library/css into plg_system_rastyling (installs to media/plg_system_rastyling/css; its image urls now point at ../../com_ra_library/images). Plugin no longer uses the component Load class. Delete media/com_ra_library/css/ramblers.css on an existing site.

v25 - ramblers.css: every extension icon and the new-window cursor now use one new-window icon, stored in the plugin (media/plg_system_rastyling/images/newwindow.png)

v26 - ramblers.css: file-type link icons are now Bootstrap Icons SVGs (MIT) in the plugin (media/plg_system_rastyling/images/icons); new-window cursor is a burgundy arrow PNG. Delete media/plg_system_rastyling/images/newwindow.png on a site that had v25.

v27 - display option "Calendar ICS download" renamed "Add to Calendar button" (form option and list label)

v28 - display option value future_icsdownload renamed future_addtocalendar; sql/updates/mysql/1.0.14.sql converts existing display records

v29 - librarydisplay.xml: Add to Calendar button preview image (your edit); media/images/displayoptions/future_addtocalendar.png added (resized to 900px)

v30 - removed unused media/images/displayoptions/calendar-regular-full.svg (delete it on an existing site)

v31 - plugin ramblers.css: Gantry 4 / RocketTheme / Joomla 3 rules commented out (marked "REMOVED (reason)"); PDF file icon unscoped from #rt-mainbody-surround and its stray background-position removed

v32 - versions bumped: package 1.0.11, com_ra_library 5.0.86, plg_system_rastyling 5.0.2 (dates 31-10-2026). Plugin ramblers.css: Jguard/JSN/helper rules commented out; new-window cursor image is 18px (hotspot 15 3). pkg_ra_library.xml: plg_system_rastyling group corrected from content to system.
