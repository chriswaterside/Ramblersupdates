<?php

/*
 * Admin email booking list
 *      parameters
 *         POST data
 *             id - id of event
 *             event - json version of walk/event Ramblers-webs format
 * 
 *      url
 *         index.php?option=com_ra_eventbooking&view=adminemailbookinglist&format=json
 * 
 * 
 */

namespace Ramblers\Component\Ra_eventbooking\Site\View\Adminemailbookinglist;

use \Ramblers\Component\Ra_eventbooking\Site\Helper\Ra_eventbookingHelper as helper;
use Joomla\CMS\Response\JsonResponse;
use Joomla\CMS\MVC\View\JsonView as BaseJsonView;
use Joomla\CMS\Factory;

// use Joomla\CMS\Component\ComponentHelper;
// No direct access
defined('_JEXEC') or die;

class JsonView extends BaseJsonView {

    public function display($tpl = null) {
        try {
            $feedback = [];
            $juser = Factory::getApplication()->getIdentity();
            $canEdit = false;
            if ($juser->id > 0) {
                $canEdit = $juser->authorise('core.edit', 'com_ra_eventbooking');
            }
            $data = helper::getPostedData();
            $ewid = $data->ewid;
            $ebRecord = helper::getEVBrecord($ewid, "Internal");
            $bookinglist = $ebRecord->getBookingTable($ebRecord->options->payment_required, $canEdit);
            $waitinglist = $ebRecord->getWaitingTable($canEdit);

            $juser = Factory::getApplication()->getIdentity();
            $to = [helper::getSendTo($juser->name, $juser->email)];

            $replyTo = null;
            $copyTo = $ebRecord->getEventContact();

            if ($copyTo->email === $juser->email) {
                $copyTo = null;
            }


            $mailTemplate = 'email_booking_list';
            $fields = $ebRecord->getAllEmailFields();
            $fields['BOOKLIST'] = $bookinglist;
            $fields['WAITINGLIST'] = $waitinglist;
            $fields['REASON'] = "";

            helper::sendEmailsToUser($to, $copyTo, $replyTo, $mailTemplate, $fields);
            $feedback[] = '<h3>Email has been sent</h3>';
            $record = (object) [
                        'feedback' => $feedback
            ];
            echo new JsonResponse($record);
        } catch (Exception $e) {
            echo new JsonResponse($e);
        }
    }
}
